
<tbody id="tbody-act">
    <?php
        $i = 1;
    ?>
    <?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <tr>
            <td><?php echo e($i++); ?></td>
            <td><?php echo e($activit->title); ?></td>
            <td><?php echo \Illuminate\Support\Str::limit($activit->description ,  50 , '...'); ?></td>

            <td width="20%" align="center">
                
                <a href="<?php echo e(route('activity.edit', $activit->id)); ?>" title="تعديل"
                    type="button" class="btn btn-primary btn-xs">
                    <span class=" glyphicon glyphicon-edit" aria-hidden="true">
                    </span>
                    تعديل
                </a>
                
                <button data-id="<?php echo e($activit->id); ?>" title="حذف" type="button"
                    class="btn btn-danger btn-xs delete">
                    <span class=" glyphicon glyphicon-trash" aria-hidden="true">
                    </span>
                    حذف
                </button> 



            </td>
        </tr>
       
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</tbody>
<?php /**PATH D:\aj\resources\views/admin/pages/activity/tbody-activity.blade.php ENDPATH**/ ?>