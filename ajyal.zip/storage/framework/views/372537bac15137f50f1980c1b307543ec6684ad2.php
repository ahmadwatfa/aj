
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>


  </div><div class="center">
 
 <div class="float-R width-900">



      <div class="topTitle">
         <span class="BGred height-36 width-12 visible float-R M-L15"></span>
         <h2 class="FN-Z20 FNBold float-R FNred"><?php echo e($active->title); ?></h2>
         <div class="clear M-B20"></div>
         <div class="width-900 float-R FNGreta  FN-Z16 FNgray" style=" line-height: 28px;">
                             

             <div class="clear"></div>
<div class="float-L width-440 M-B15 M-R20">

                                     <img src="<?php echo e(asset('storage/' . $active->image)); ?>" title="<?php echo e($active->title); ?>" alt="<?php echo e($active->title); ?> " width="350px" height="350px"/>
                                                 </div>
                 <p class="FNGreta FN-Z16 FNgray textAlg-J textDesc"> <?php echo $active->description; ?></p>



         <div class="clear"></div>
         </div>
         <div class="clear"></div>
     </div>
     <div class="clear"></div>
     <!-- /topTitle -->



 </div>
 <!-- /.float-R -->



    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aj\resources\views/activity.blade.php ENDPATH**/ ?>