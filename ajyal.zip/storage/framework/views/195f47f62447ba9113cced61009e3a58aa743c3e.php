<?php $__env->startSection('main'); ?>
            </aside>
     <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          
          <ol class="breadcrumb">
            <li><a href=""><i class="fa fa-home"></i> الرئيسية</a></li>
            <li class="active">قائمة المستخدمين</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
         
          <div class="row">
            <div class="col-xs-12">
           
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title"> <i class="fa fa-users"></i> قائمة المستخدمين </h3>
                  <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary pull-left"><i class="fa fa-plus"></i> إضافة مستخدم جديد </a>

                </div><!-- /.box-header -->
                <div class="box-body">
                  <table class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>رقم </th>
                        <th>اسم المستخدم</th>
                        <th>الايميل</th>
                        <th>الصلاحية</th>
                        <th>العمليات</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $i=1;    
                      ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    
                      <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->role == 'super_admin' ? "مدير" : "مشرف موقع"); ?></td>
                        <td width="20%" align="center">

                                                        
                          <a href="<?php echo e(route('user.edit' , $user->id)); ?>" class="btn btn-primary btn-xs">تعديل</a>

                          <form  style="display: inline" action="<?php echo e(route('user.destroy' , $user->id)); ?>" method="post">
                             <?php echo method_field('delete'); ?>
                             <?php echo csrf_field(); ?>
                              <button type="submit" class="btn btn-danger btn-xs">حذف</button>
                          </form>
                      </td>

                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                    
                  


                    </tbody>

                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->

          <div class="modal fade" id="myModal" role="dialog">
              <div class="modal-dialog modal-sm">
                  <div class="modal-content">
                      <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                          <h4 class="modal-title">تأكيد عملية الحذف</h4>
                      </div>
                      <div class="modal-body">
                          <p>هل انت متأكد من حذف المستخدم؟</p>
                      </div>
                      <div class="modal-footer">
                          <form id="del-form" action="" method="post">
                              <button type="submit" class="btn btn-danger" >حذف</button>
                          </form>
                      </div>
                  </div>
              </div>
          </div>

      </div><!-- /.content-wrapper -->

      <script>

          function confirmDelete(id) {
              $('#del-form').attr('action',"admin/delete-user/"+id);
              $('#myModal').modal();
          }

      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ajyal\resources\views/admin/pages/user/user-table.blade.php ENDPATH**/ ?>