<html xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="description" content="طاقم شؤون المرأة">
    <meta name="keywords" content="طاقم شؤون المرأة">
    <meta name="robots" content="all">
    <base href="https://www.watcpal.org/">
    <link rel="shortcut icon" href="assets/images/icon.png" type="image/x-icon">
    <!-- Our CSS stylesheet file -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/jsCarousel-2.0.0.css">
        <link rel="stylesheet" href="assets/css/flexslider.css" type="text/css" media="screen">
        <link href="assets/css/calender.css" rel="stylesheet">
        <!-- Owl Stylesheets -->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
        <link rel="stylesheet" href="assets/fancybox/jquery.fancybox.css?v=2.1.5">
            <link href="assets/news-ticker/styles/ticker-style.css" rel="stylesheet" type="text/css">
            <style type="text/css">
              img.wp-smiley,
              img.emoji {
                  display: inline !important;
                  border: none !important;
                  box-shadow: none !important;
                  height: 1em !important;
                  width: 1em !important;
                  margin: 0 .07em !important;
                  vertical-align: -0.1em !important;
                  background: none !important;
                  padding: 0 !important;
              }
              </style>
              <link rel="stylesheet" id="wp-block-library-rtl-css" href="http://civitas.ps/ar/wp-includes/css/style-rtl.min.css" type="text/css" media="all">
              <link rel="stylesheet" id="contact-form-7-css" href="http://civitas.ps/ar/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=4.4.2" type="text/css" media="all">
              <link rel="stylesheet" id="contact-form-7-rtl-css" href="http://civitas.ps/ar/wp-content/plugins/contact-form-7/includes/css/styles-rtl.css?ver=4.4.2" type="text/css" media="all">
              <link rel="stylesheet" id="Bootstrap-style-css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css?ver=3.3.6" type="text/css" media="all">
              <link rel="stylesheet" id="Bootstrap-rtl-style-css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-rtl/3.2.0-rc2/css/bootstrap-rtl.min.css?ver=3.2.0" type="text/css" media="all">
              <link rel="stylesheet" id="font-awesome-css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css?ver=4.6.3" type="text/css" media="all">
              <link rel="stylesheet" id="ekko-lightbox-css" href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/4.0.1/ekko-lightbox.min.css?ver=4.0.1" type="text/css" media="all">
              <link rel="stylesheet" id="typography-css" href="http://civitas.ps/ar/wp-content/themes/Civitas/css/typography.css?ver=5.1.10" type="text/css" media="all">
              <link rel="stylesheet" id="civitas-style-css" href="http://civitas.ps/ar/wp-content/themes/Civitas/style.css?ver=5.1.10" type="text/css" media="all">
              <link rel="stylesheet" id="responsive-css" href="http://civitas.ps/ar/wp-content/themes/Civitas/css/responsive.css?ver=5.1.10" type="text/css" media="all">
              <link rel="stylesheet" id="fontsans-css" href="http://fonts.googleapis.com/css?family=PT+Sans%3A400%2C700&amp;subset=latin-ext&amp;ver=5.1.10" type="text/css" media="all">
              <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
              <link rel="https://api.w.org/" href="http://civitas.ps/ar/wp-json/">
              <link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://civitas.ps/ar/xmlrpc.php?rsd">
              <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://civitas.ps/ar/wp-includes/wlwmanifest.xml">
              <link rel="stylesheet" href="http://civitas.ps/ar/wp-content/themes/Civitas/rtl.css" type="text/css" media="screen"><meta name="generator" content="WordPress 5.1.10">
              <style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
              <style type="text/css">#mc_embed_signup input.mce_inline_error { border-color:#6B0505; } #mc_embed_signup div.mce_inline_error { margin: 0 0 1em 0; padding: 5px 10px; background-color:#6B0505; font-weight: bold; z-index: 1; color:#fff; }</style>
                  
                
    <title>مؤسسة أجيال للتدريب والتطوير</title>
    <style type="text/css" data-fbcssmodules="css:fb.css.base css:fb.css.dialog css:fb.css.iframewidget css:fb.css.customer_chat_plugin_iframe">.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:"lucida grande", tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}@keyframes  fb_transform{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}
    .fb_dialog{background:rgba(82, 82, 82, .7);position:absolute;top:-10000px;z-index:10001}.fb_dialog_advanced{border-radius:8px;padding:10px}.fb_dialog_content{background:#fff;color:#373737}.fb_dialog_close_icon{background:url(https://z-p3-static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{left:5px;right:auto;top:5px}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(https://z-p3-static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent}.fb_dialog_close_icon:active{background:url(https://z-p3-static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #365899;color:#fff;font-size:14px;font-weight:bold;margin:0}.fb_dialog_content .dialog_title>span{background:url(https://z-p3-static.xx.fbcdn.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;float:left;padding:5px 0 7px 26px}body.fb_hidden{height:100%;left:0;margin:0;overflow:visible;position:absolute;top:-10000px;transform:none;width:100%}.fb_dialog.fb_dialog_mobile.loading{background:url(https://z-p3-static.xx.fbcdn.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;min-height:100%;min-width:100%;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{background:none;height:auto;min-height:initial;min-width:initial;width:auto}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100%}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{clear:both;color:#fff;display:block;font-size:18px;padding-top:20px}#fb-root #fb_dialog_ipad_overlay{background:rgba(0, 0, 0, .4);bottom:0;left:0;min-height:100%;position:absolute;right:0;top:0;width:100%;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_mobile .fb_dialog_iframe{position:sticky;top:0}.fb_dialog_content .dialog_header{background:linear-gradient(from(#738aba), to(#2c4987));border-bottom:1px solid;border-color:#043b87;box-shadow:white 0 1px 1px -1px inset;color:#fff;font:bold 14px Helvetica, sans-serif;text-overflow:ellipsis;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{height:43px;width:100%}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:linear-gradient(from(#4267B2), to(#2a4887));background-clip:padding-box;border:1px solid #29487d;border-radius:3px;display:inline-block;line-height:18px;margin-top:3px;max-width:85px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{background:none;border:none;color:#fff;font:bold 12px Helvetica, sans-serif;margin:2px -12px;padding:2px 6px 3px 6px;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:bold;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(https://z-p3-static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;border:1px solid #4a4a4a;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f5f6f7;border:1px solid #4a4a4a;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(https://z-p3-static.xx.fbcdn.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);background-position:50% 50%;background-repeat:no-repeat;height:24px;width:24px}@keyframes  rotateSpinner{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
    .fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100%}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100%}
    .fb_mpn_mobile_landing_page_slide_out{animation-duration:200ms;animation-name:fb_mpn_landing_page_slide_out;transition-timing-function:ease-in}.fb_mpn_mobile_landing_page_slide_out_from_left{animation-duration:200ms;animation-name:fb_mpn_landing_page_slide_out_from_left;transition-timing-function:ease-in}.fb_mpn_mobile_landing_page_slide_up{animation-duration:500ms;animation-name:fb_mpn_landing_page_slide_up;transition-timing-function:ease-in}.fb_mpn_mobile_bounce_in{animation-duration:300ms;animation-name:fb_mpn_bounce_in;transition-timing-function:ease-in}.fb_mpn_mobile_bounce_out{animation-duration:300ms;animation-name:fb_mpn_bounce_out;transition-timing-function:ease-in}.fb_mpn_mobile_bounce_out_v2{animation-duration:300ms;animation-name:fb_mpn_fade_out;transition-timing-function:ease-in}.fb_customer_chat_bounce_in_v2{animation-duration:300ms;animation-name:fb_bounce_in_v2;transition-timing-function:ease-in}.fb_customer_chat_bounce_in_from_left{animation-duration:300ms;animation-name:fb_bounce_in_from_left;transition-timing-function:ease-in}.fb_customer_chat_bounce_out_v2{animation-duration:300ms;animation-name:fb_bounce_out_v2;transition-timing-function:ease-in}.fb_customer_chat_bounce_out_from_left{animation-duration:300ms;animation-name:fb_bounce_out_from_left;transition-timing-function:ease-in}.fb_invisible_flow{display:inherit;height:0;overflow-x:hidden;width:0}@keyframes  fb_mpn_landing_page_slide_out{0%{margin:0 12px;width:100% - 24px}60%{border-radius:18px}100%{border-radius:50%;margin:0 24px;width:60px}}@keyframes  fb_mpn_landing_page_slide_out_from_left{0%{left:12px;width:100% - 24px}60%{border-radius:18px}100%{border-radius:50%;left:12px;width:60px}}@keyframes  fb_mpn_landing_page_slide_up{0%{bottom:0;opacity:0}100%{bottom:24px;opacity:1}}@keyframes  fb_mpn_bounce_in{0%{opacity:.5;top:100%}100%{opacity:1;top:0}}@keyframes  fb_mpn_fade_out{0%{bottom:30px;opacity:1}100%{bottom:0;opacity:0}}@keyframes  fb_mpn_bounce_out{0%{opacity:1;top:0}100%{opacity:.5;top:100%}}@keyframes  fb_bounce_in_v2{0%{opacity:0;transform:scale(0, 0);transform-origin:bottom right}50%{transform:scale(1.03, 1.03);transform-origin:bottom right}100%{opacity:1;transform:scale(1, 1);transform-origin:bottom right}}@keyframes  fb_bounce_in_from_left{0%{opacity:0;transform:scale(0, 0);transform-origin:bottom left}50%{transform:scale(1.03, 1.03);transform-origin:bottom left}100%{opacity:1;transform:scale(1, 1);transform-origin:bottom left}}@keyframes  fb_bounce_out_v2{0%{opacity:1;transform:scale(1, 1);transform-origin:bottom right}100%{opacity:0;transform:scale(0, 0);transform-origin:bottom right}}@keyframes  fb_bounce_out_from_left{0%{opacity:1;transform:scale(1, 1);transform-origin:bottom left}100%{opacity:0;transform:scale(0, 0);transform-origin:bottom left}}@keyframes  slideInFromBottom{0%{opacity:.1;transform:translateY(100%)}100%{opacity:1;transform:translateY(0)}}@keyframes  slideInFromBottomDelay{0%{opacity:0;transform:translateY(100%)}97%{opacity:0;transform:translateY(100%)}100%{opacity:1;transform:translateY(0)}}</style></head>
    <body style="" data-new-gr-c-s-check-loaded="14.1029.0" data-gr-ext-installed="">

    <div id="fb-root" class=" fb_reset"><div style="position: absolute; top: -10000px; width: 0px; height: 0px;"><div></div></div></div>
    

        <header>
            <div class="bgmenu BGwhite"></div>
            <div class="bgslide BGdred opacity90"></div>
            <div class="linetatrez opacity80"></div>
            <div class="slidebg"></div>
            <div class="center">
               <a href="home">	<div id="logo"><h1></h1></div></a>
                <!-- /#logo -->
                <div id="Ssocial">
                    <!--<div class="link FNssB FN-Z13">
                        <a href="#">عربي</a>
                        <a href="#">English</a>
                        <a href="#">Espanol</a>
                        <div class="clear"></div>
                    </div> -->
                    <div class="media">
                        <a href="https://twitter.com/WATCPal" class="twitter" title="Twitter"></a>
                        <a href="https://www.facebook.com/WATCPAL/?fref=ts>" class="facebook" title="Facebook"></a>
                        <a href="https://plus.google.com/u/0/115401034300149826013/posts" class="google" title="Google+"></a>
                        <a href="https://www.youtube.com/channel/UCpTuMfNmIdUPDd-6xk_yzgQ/videos" class="youtube" title="YouTube"></a>
                        <a href="https://soundcloud.com/user-262418958" class="sound" title="SoundCloud"></a>
                    </div>
                        <a href="https://www.watcpal.org/en" class="FN-Z16 FNBold FNred float-L" title="English">English</a>
                    <!--<input type="text" name="search" class="search" placeholder="بحث...." />-->

                </div>
                <!-- /#Ssocial -->


                <ul id="menu" class="FN-Z15 FNBold">
                    <li><a href="home">الرئيسية</a></li>
                    <li><a href="home">عن أجيال</a></li>
                    <li><a href="home">الخطة الاستراتيجية</a></li>
                    <li><a href="home">التقارير</a></li>
                    <li><a href="home">هيكلية المؤسسة</a></li>
                    <li><a href="home">اتصل بنا</a></li>

                </ul>
                <div class="lastnews FNwhite">

                
                <div id="ticker-wrapper-1632734188685" class="ticker-wrapper has-js right">
                    <div id="ticker-1632734188685" class="ticker">
                       
                            <div id="ticker-swipe-1632734188685" class="ticker-swipe" style="right: 43px; margin-right: 58.5px;">
                                </div>
                            </div>
                        </div>

                </div>
                
    <?php echo $__env->yieldContent('content'); ?>




            <!-- #footer -->
            <footer id="footer">
                <div class="container-fluid pad-r">
                    <div id="top-footer">
                        <div class="row">
                            <div class="col-md-3">
                                <h3>حول المركز</h3>
                                <p>
                                    مركز دراسات المجتمع المدني:
                                    هو مؤسسة أهلية فلسطينية، غير هادفة للربح، محايدة، مستقلة، وغير حزبية، تأسست في قطاع
                                    غزة في العام 2001م؛ تعمل في مجال التطوير المجتمعي وتنمية وتعزيز قواعد المجتمع المدني
                                    من منظمات أهلية ومبادرات محلية ناشئة عن حاجات المجتمع الفلسطيني؛ وذلك في أعقاب
                                    التغيرات السياسية التي طرأت على المجتمع الفلسطيني والمتمثلة بقيام السلطة الوطنية وما
                                    تشكله من لبنة أولى على طريق التحرر والاستقلال التام؛ فقد كان لزاماً ضرورة العمل
                                    والاسهام في بناء دولة المؤسسات على أساس من الحريات، سيادة القانون، المساواة،
                                    والعدالة الاجتماعية. </p>
                                <address class="vcard">
                                    <p class="tel">
                                        <i class="fa fa-phone fa-lg"></i>
                                        2639466
                                    </p>
                                    <i class="fa fa-envelope fa-lg"></i>
                                    <a class="email" target="_blank" href="mailto:info@civitas.ps">
                                        <small>
                                            info@civitas.ps </small>
                                    </a>

                                </address>
                            </div>
                            <!-- /.col-md-3 -->

                            <div class="col-md-3 col-md-offset-1">
                                <h3>روابط خارجية</h3>
                                <div class="menu-footer-container">
                                    <ul id="menu-footer" class="menu">
                                        <li id="menu-item-96"
                                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-96">
                                            <a
                                                href="https://www.facebook.com/%D8%B1%D8%A7%D8%A8%D8%B7%D8%A9%D9%8F-%D8%A7%D9%84%D9%86%D8%A7%D8%B2%D8%AD%D9%8A%D9%86-%D9%88%D8%A7%D9%84%D9%85%D9%8F%D9%87%D9%8E%D8%AC%D9%91%D9%8E%D8%B1%D9%8A%D9%86-%D8%A7%D9%84%D9%81%D9%84%D8%B3%D8%B7%D9%8A%D9%86%D9%8A%D9%8A%D9%86-IDPs-League-1581441145412443/">رابطةُ
                                                النازحين والمُهَجَّرين الفلسطينيين</a>
                                        </li>
                                        <li id="menu-item-98"
                                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-98">
                                            <a
                                                href="https://www.facebook.com/CROLD-for-Monitoring-Reconstruction%D8%A7%D9%84%D8%AA%D8%AD%D8%A7%D9%84%D9%81-%D8%A7%D9%84%D9%85%D8%AF%D9%86%D9%8A-%D9%84%D9%84%D8%B1%D9%82%D8%A7%D8%A8%D8%A9-%D8%B9%D9%84%D9%89-%D8%A5%D8%B9%D8%A7%D8%AF%D8%A9-%D8%A7%D9%84%D8%A5%D8%B9%D9%85%D8%A7%D8%B1-1063338107063981/">التحالف
                                                المدني للرقابة على إعادة الإعمار</a>
                                        </li>
                                        <li id="menu-item-99"
                                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-99">
                                            <a href="https://www.facebook.com/palestine1948war/">حملة شباب من أجل
                                                التغيير</a>
                                        </li>
                                        <li id="menu-item-100"
                                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-100">
                                            <a href="https://www.facebook.com/Civitas.Dialouge/">الحملة الوطنية لتعزيز
                                                ثقافة الحوار</a>
                                        </li>
                                        <li id="menu-item-101"
                                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-101">
                                            <a
                                                href="https://www.facebook.com/Supreme-Commission-for-Alleviating-Poverty-SCAP-1742431742636385/">Supreme
                                                Commission for Alleviating Poverty – SCAP</a>
                                        </li>
                                        <li id="menu-item-102"
                                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-102">
                                            <a
                                                href="https://www.facebook.com/Getting-to-Yes-Group-GYG-%D9%85%D8%AC%D9%85%D9%88%D8%B9%D8%A9-%D8%A7%D9%84%D8%AA%D9%88%D8%A7%D9%81%D9%82-%D9%88%D8%A7%D9%84%D8%B1%D8%B6%D8%A7-1461444377427072/">مجموعة
                                                التوافق والرضا</a>
                                        </li>
                                        <li id="menu-item-106"
                                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-106">
                                            <a
                                                href="https://www.facebook.com/WIFE-Womenism-Initiative-For-Equity-1148430935176987/">“WIFE
                                                “Womenism Initiative For Equity</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <!-- /.col-md-3 -->
                            <div class="col-md-4 col-md-offset-1 pad-l">
                                <h3>اتصل بنا</h3>

                                <div role="form" class="wpcf7" id="wpcf7-f25-o1" lang="ar" dir="rtl">
                                    <div class="screen-reader-response"></div>
                                    <form action="/ar/#wpcf7-f25-o1" method="post" class="wpcf7-form"
                                        novalidate="novalidate">
                                        <div style="display: none;">
                                            <input type="hidden" name="_wpcf7" value="25">
                                            <input type="hidden" name="_wpcf7_version" value="4.4.2">
                                            <input type="hidden" name="_wpcf7_locale" value="ar">
                                            <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f25-o1">
                                            <input type="hidden" name="_wpnonce" value="a7b0d98bd0">
                                        </div>
                                        <div class="form-group">
                                            <span class="wpcf7-form-control-wrap your-name"><input type="text"
                                                    name="your-name" value="" size="40"
                                                    class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-control"
                                                    id="focusedInput" aria-required="true" aria-invalid="false"
                                                    placeholder="الاسم ..."></span>
                                        </div>
                                        <div class="form-group ">
                                            <span class="wpcf7-form-control-wrap your-email"><input type="email"
                                                    name="your-email" value="" size="40"
                                                    class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email form-control"
                                                    id="email" aria-required="true" aria-invalid="false"
                                                    placeholder="البريد الإلكتروني..."></span>
                                        </div>
                                        <div class="form-group">
                                            <span class="wpcf7-form-control-wrap your-subject"><input type="text"
                                                    name="your-subject" value="" size="40"
                                                    class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-control"
                                                    id="focusedInput2" aria-required="true" aria-invalid="false"
                                                    placeholder="الموضوع..."></span>
                                        </div>
                                        <div class="form-group">
                                            <span class="wpcf7-form-control-wrap your-message"><textarea
                                                    name="your-message" cols="40" rows="10"
                                                    class="wpcf7-form-control wpcf7-textarea wpcf7-validates-as-required form-control"
                                                    id="comment" aria-required="true" aria-invalid="false"
                                                    placeholder="الرسالة..."></textarea></span>
                                        </div>
                                        <div class="pull-left">
                                            <input type="submit" value="ارسال"
                                                class="wpcf7-form-control wpcf7-submit btn-default"><br>
                                            <!-- input:submit -->
                                        </div>
                                        <div class="wpcf7-response-output wpcf7-display-none"></div>
                                    </form>
                                </div>
                            </div>
                            <!-- /.col-md-4 -->
                        </div>
                    </div>
                    <!-- #top-footer -->
                    <!-- /.row -->
                </div>
                <!-- /.container-fulid -->
            </footer>
            <!-- /#footer -->
    </div>
    </body>
    <grammarly-desktop-integration data-grammarly-shadow-root="true"></grammarly-desktop-integration>

    </html>


<?php /**PATH D:\ajyal\resources\views/layouts/index.blade.php ENDPATH**/ ?>