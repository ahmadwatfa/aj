
   <header style="min-height: 212px;">
       <div class="center">
       
        <!-- /#logo -->
        <div id="Ssocial">

            <div class="media">
                <a href="https://twitter.com/WATCPal" class="twitter" title="Twitter"></a>
                <a href="https://www.facebook.com/WATCPAL/?fref=ts>" class="facebook" title="Facebook"></a>
                <a href="https://plus.google.com/u/0/115401034300149826013/posts" class="google" title="Google+"></a>
                <a href="https://www.youtube.com/channel/UCpTuMfNmIdUPDd-6xk_yzgQ/videos" class="youtube" title="YouTube"></a>
                <a href="https://soundcloud.com/user-262418958" class="sound" title="SoundCloud"></a>
            </div>
                
        </div>
        <!-- /#Ssocial -->


        <ul id="menu" class="FN-Z15 FNBold" >
            <li><a href="<?php echo e(route('index')); ?>">الرئيسية</a></li>
            <li><a href="<?php echo e(route('about')); ?>">عن أجيال</a></li>
            <li><a href="<?php echo e(route('plane')); ?>">الخطة الاستراتيجية</a></li>
            <li><a href="<?php echo e(route('report')); ?>">التقارير</a></li>
            <li><a href="<?php echo e(route('staff')); ?>">هيكلية المؤسسة</a></li>
            <li><a href="<?php echo e(route('contact')); ?>">إتصل بنا</a></li>

        </ul>

    </div>
    <!-- /.center -->
<style>
#menu li a {
    display: block;
    padding: 5px 10px;
    color: #231f20;
    font-weight: 900;
    font-size: 18px;
    font-family: 'Cairo';
}
h2{
    font-family: 'Cairo';
}
</style>
</header>
<?php /**PATH D:\aj\resources\views/layouts/header.blade.php ENDPATH**/ ?>