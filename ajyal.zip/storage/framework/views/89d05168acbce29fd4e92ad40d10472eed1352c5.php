<?php $__env->startSection('content'); ?>

<div id="slide">


    <a href="posts/128" class="s1">
         <h2 class="FNBold FN-Z18">تدريب  الشباب ضمن جيل جديد3 على العدالة الاجتماعية</h2>
         <!--<div class="bgcolor"></div>-->
    <img src="https://www.watcpal.org/thumb.php?src=https://www.watcpal.org/upload/4b632ef09be752494682c8d4c0216aec.jpg&amp;w=600&amp;h=336&amp;zc=0" alt="تدريب  الشباب ضمن جيل جديد3 على العدالة الاجتماعية" title="تدريب  الشباب ضمن جيل جديد3 على العدالة الاجتماعية" width="600" height="336">
     </a>
                   <div class="s2">

     <a href="posts/126" class="s3">
         <h2 class="FNGreta FN-Z18">طاقم شؤون المرأة ينظم فعالية الحفل الختامي لمشروع رياضة من أجل فتيات فلسطين</h2>
         <!--<div class="bgcolor2"></div>-->    <img src="https://www.watcpal.org/thumb.php?src=https://www.watcpal.org/assets/images/noimage.jpg&amp;w=300&amp;h=168&amp;zc=2" alt="طاقم شؤون المرأة ينظم فعالية الحفل الختامي لمشروع رياضة من أجل فتيات فلسطين" title="طاقم شؤون المرأة ينظم فعالية الحفل الختامي لمشروع رياضة من أجل فتيات فلسطين" width="300" height="168">     </a>

     <a href="posts/118" class="s3">
         <h2 class="FNGreta FN-Z18">طاقم شؤون المرأة  يشارك في أعمال الدورة الثانية والستين للجنة وضع المرأة في مقر الأمم المتحدة بنيويورك</h2>
         <!--<div class="bgcolor2"></div>-->    <img src="https://www.watcpal.org/thumb.php?src=https://www.watcpal.org/upload/9bf34b617ba6724ad0e90fc328aa5b19.jpg&amp;w=300&amp;h=168&amp;zc=0" alt="طاقم شؤون المرأة  يشارك في أعمال الدورة الثانية والستين للجنة وضع المرأة في مقر الأمم المتحدة بنيويورك" title="طاقم شؤون المرأة  يشارك في أعمال الدورة الثانية والستين للجنة وضع المرأة في مقر الأمم المتحدة بنيويورك" width="300" height="168">     </a>
                  </div>



<div class="s4 float-R M-R10">

<a target="_blank" href="http://93.184.4.130/watcpal/remembrance"><img src="assets/images/1.jpg" width="222" height="335"></a>
</div>
<div class="clear"></div>
</div>
<!-- /slide -->
</div>
<!-- /.center -->

</header>
<div class="headerpicdown"></div>&#xFEFF;	<div class="center">
</div>

<div>
    <!-- .wrap -->
    <div id="wrap">
        <!-- #header -->
        <header id="header">




            <!-- #content -->

            <main id="content" class="narrowcolumn">

                <div class="container-fluid">

                    <div class="row">

                        <div class="col-md-8 pad-r no-pad-l">





                            <!-- /.Slider -->

                            <section class="botom-latest-news">

                                <div class="nice-box">

                                    <div class="light-boxt"></div>

                                    <div class="dark-boxt"></div>

                                    <div class="light-box"></div>

                                    <div class="dark-box"></div>

                                </div>

                                <!-- /.noce-box -->

                                <div class="title-bar">

                                    <h3>اخر الأخبار</h3>

                                </div>

                                <!-- /.title-bar -->

                                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="news-box">
                                    
                                        
                                    
                                    <div class="row">

                                        <div class="col-sm-3 col-xs-12">

                                            <img height="110"
                                                src="<?php echo e(asset('storage/' . $activity->image)); ?>"
                                                alt="Slider Image">

                                        </div>

                                        <!-- col-md-3 -->

                                        <div class="col-sm-8 col-xs-12">

                                            <a href=""
                                                target="_blank">

                                                <h4><?php echo e($activity->title); ?></h4>

                                            </a>

                                            <p><?php echo $activity->description; ?></p>

                                            <a href="http://civitas.ps/ar/2021/09/23/%d9%8a%d9%88%d9%85-%d8%af%d8%b1%d8%a7%d8%b3%d9%8a-%d9%84%d8%b9%d8%b1%d8%b6-%d9%86%d8%aa%d8%a7%d8%a6%d8%ac-%d8%a7%d9%84%d9%85%d8%b3%d8%ad-%d8%a7%d9%84%d9%85%d9%8a%d8%af%d8%a7%d9%86%d9%8a-%d9%84/"
                                                target="_blank" class="pull-left nice">

                                                إقرأ المزيد

                                            </a>

                                        </div>

                                        <!-- /.col-md-8 -->

                                    </div>
                                   
                                    <!-- /.row -->

                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </section>
                            <!-- /.botom-latest-news -->

                            <section class="doners">

                                <div class="nice-box">

                                    <div class="light-boxt"></div>

                                    <div class="dark-boxt"></div>

                                    <div class="light-box"></div>

                                    <div class="dark-box"></div>

                                </div>

                                <!-- /.noce-box -->

                                <div class="title-bar">

                                    <h3>المانحون</h3>
                                </div>

                                <div class="doner-logo">

                                    <div class="row">


                                    </div>

                                    <!-- /.row -->

                                </div>

                                <!-- /.doner-logo -->

                            </section>
                           

                        </div>



                        <!-- /.col-md-8 -->

                  

                        <!-- /.col-md-3 -->

                    </div>

                    <!-- /.row-fluid -->

                </div>

                <!-- /.container-fluid -->

            </main>

            <!-- /#content -->




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ajyal\resources\views/index.blade.php ENDPATH**/ ?>