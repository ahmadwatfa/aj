<?php $__env->startSection('main'); ?>
            </aside>
                <!-- Content Wrapper. Contains page content -->
                <div class="content-wrapper">
                    <!-- Content Header (Page header) -->
                    <section class="content-header">

                        <ol class="breadcrumb">
                            <li><a href="admin"><i class="fa fa-home"></i> الرئيسية</a></li>
                            <li class="active">قائمة العروض</li>
                        </ol>
                    </section>

                    <!-- Main content -->
                    <section class="content">

                        <div class="row">
                            <div class="col-xs-12">
                                <?php if(session()->has('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                                <?php if(session()->has('update')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('update')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session()->has('delete')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('delete')); ?>

                                </div>
                            <?php endif; ?>
                           
                                <div class="box box-primary">
                                    <div class="box-header with-border">
                                        <h3 class="box-title"> <i class="fa fa-laptop"></i> قائمة العروض </h3>
                                        <a href="<?php echo e(route('about.create')); ?>" class="btn btn-primary pull-left"><i
                                                class="fa fa-plus"></i> إضافة نبذة جديد </a>

                                    </div><!-- /.box-header -->
                                    <div class="box-body">
                                        <table id="example1" class="table table-bordered table-striped">
                                            <thead>
                                                
                                                    
                                               
                                                <tr>
                                                    <th>رقم </th>
                                                    
                                                    <th>النبذة</th>
                                                    <th>العمليات</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $i = 1;    
                                                ?>
                                             <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 
                                             
                                                <tr>
                                                    
                                                    <td><?php echo e($i++); ?></td>
                                                
                                                    <td><?php echo \Illuminate\Support\Str::limit($about->description ,  50 , '...'); ?></td>
                                                 
                                                    <td width="20%" align="center">
                                                        <a href="<?php echo e(route('about.show' , $about->id )); ?>" class="btn btn-xs <?php echo e($about->is_publish ?  "btn-default" : "btn-warning"); ?>"><?php echo e($about->is_publish ? "عدم نشر" : "نشر"); ?></a>
                                                        
                                                        <a href="<?php echo e(route('about.edit' , $about->id )); ?>" class="btn btn-primary btn-xs">تعديل</a>

                                                        <button onclick="confirmDelete()" title="حذف" type="button"
                                                        class="btn btn-danger btn-xs delete">
                                                        <span class=" glyphicon glyphicon-trash" aria-hidden="true">
                                                        </span>
                                                        حذف
                                                    </button>



                                                </td>
                                            </tr>
                                            <div class="modal fade" id="myModal" role="dialog">
                                                <div class="modal-dialog modal-sm">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="close"
                                                                data-dismiss="modal">&times;</button>
                                                            <h4 class="modal-title">تأكيد عملية الحذف</h4>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>هل انت متأكد من حذف النبذة؟</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <form
                                                                action="<?php echo e(route('about.destroy', $about->id)); ?>"
                                                                method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('delete'); ?>
                                                                <button type="submit"
                                                                    class="btn btn-danger">حذف</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                            </div><!-- /.content-wrapper -->
                            <script>
                                function confirmDelete(id) {
                                    $('#del-form').attr('action', '/admin/about');
                                    $('#myModal').modal();
                                }
                            </script>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tbody>

                            </table>
                        </div><!-- /.box-body -->
                    </div><!-- /.box -->
                </div><!-- /.col -->
            </div><!-- /.row -->
    </section><!-- /.content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ajyal\resources\views/admin/pages/about/about_table.blade.php ENDPATH**/ ?>