<div class="clear"></div>
<footer class="M-T15">
    <div class="center">
        <div class="line BGgray M-B20 M-T20"></div>
        <div class="map width-590 float-R">
                <span class="iconPlace float-R visible M-T50"></span>
                  <span class="M-R10 FN-Z15 FNBold FNred title visible float-R M-T50">شارع الارسال-عمارة عواد، الطابق الثاني ص ب 2197، رام الله.<br>
<span style="float:right;">تلفون :  </span> <span style="direction:ltr; display:block;float:right;">97222987783/4</span></span>
             </div>
                
        </div>

        <div class="map width-590 float-L">
                <span class="iconPlace float-R visible M-T50"></span>
                  <span class="M-R10 FN-Z15 FNBold FNred title visible float-R M-T50">شارع عمان-غرب دوار أبومازن، بجوار عمارة بيروت الطابق الأول، غزة<br>
<span style="float:right;">تلفون :  </span> <span style="direction:ltr; display:block; float:right;"> 08-2644322</span></span>
            </div>
                <div class="clear"></div>
        </div>

        <div class="clear"></div>

        <div id="logo" class="float-R M-L10"></div>
        <span class="FNred float-R FN-Z15 FNBold M-T20"></span>
        <span class="width-12 height-36 BGdred visible float-R M-T15 M-R10 M-L10"></span>
        <span class="copyright FN-Z13 FNBold M-R10 FNred M-T20 float-R"></span>

        

        <div class="clear"></div>
    </div>
    <!-- /.center -->
    <div class="clear"></div>
    <div class="linetatrez"></div>

</footer><?php /**PATH D:\aj\resources\views/layouts/footer.blade.php ENDPATH**/ ?>