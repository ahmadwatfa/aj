
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>



   <body data-new-gr-c-s-check-loaded="14.1031.0" data-gr-ext-installed="" style="">

    <div class="center">
    
                    <!-- /Ads -->

                    <div class="float-R width-900">





                        <div class="topTitle">

                            <span class="BGred height-36 width-12 visible float-R M-L15"></span>

                            <h2 class="FN-Z20 float-R FNred"> طاقم أجيال</h2>

                            <div class="clear M-B20"></div>

                            <div class="width-900 float-R FNGreta  FN-Z16 FNgray" style=" line-height: 28px;">

                              

                            <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                           
                                    <p class="FNGreta FN-Z16 FNgray textAlg-J textDesc"><?php echo $st->staff; ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="clear"></div>

                            </div>

                            <div class="clear"></div>

                        </div>



                        <div class="clear"></div>

                        <!-- /topTitle -->







                    </div>

                    <!-- /.float-R -->



                

                    <div class="clear M-B20"></div>





                </div>

           <div class="clear"></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aj\resources\views/staff.blade.php ENDPATH**/ ?>