<?php $__env->startSection('main'); ?>
    </aside>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">

            <ol class="breadcrumb">
                <li><a href="admin"><i class="fa fa-home"></i> الرئيسية</a></li>
                <li class="active">قائمة الخطط الاستراتيجية</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">

            <div class="row">
                <div class="col-xs-12">

                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title"> <i class="fa fa-laptop"></i> قائمة الخطط الاستراتيجية </h3>
                            <a href="<?php echo e(route('plane.create')); ?>" class="btn btn-primary pull-left">
                                <i class="fa fa-plus"></i> إضافة خطة جديدة </a>

                        </div><!-- /.box-header -->
                        <div class="box-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <?php if(session()->has('success')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(session()->has('delete')): ?>
                                    <div class="alert alert-danger">
                                        <?php echo e(session('delete')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(session()->has('update')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('update')); ?>

                                    </div>
                                <?php endif; ?>
                                <thead>



                                    <tr>
                                        <th>رقم </th>
                                        <th>الخطة</th>
                                       
                                        <th>العمليات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $plane; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo \Illuminate\Support\Str::limit($plan->plane ,  50 , '...'); ?></td>
                                           
                                            <td width="20%" align="center">

                                                <a href="<?php echo e(route('plane.edit' , $plan->id)); ?>" title="تعديل" type="button" class="btn btn-primary btn-xs">
                                                                          <span class=" glyphicon glyphicon-edit" aria-hidden="true">
                                                                          </span>
                                                  تعديل
                                                </a>
                      
                                                <form  style="display: inline" action="<?php echo e(route('plane.destroy' , $plan->id)); ?>" method="post">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                     <button type="submit" class="btn btn-danger btn-xs">حذف</button>
                                                 </form>
                      
                      
                      
                                              </td>
                                            </tr>
                                            <div class="modal fade" id="myModal" role="dialog">
                                                <div class="modal-dialog modal-sm">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                            <h4 class="modal-title">تأكيد عملية الحذف</h4>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>هل انت متأكد من حذف الشريك؟</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <form  action="<?php echo e(route('partner.destroy' , $plan->id)); ?>" method="post">
                                                               <?php echo csrf_field(); ?>
                                                               <?php echo method_field('delete'); ?>
                                                                
                                                                <button type="submit" class="btn btn-danger">حذف</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- /.content-wrapper -->
                                        <script>
                                  
                                            function confirmDelete(id) {
                                                $('#del-form').attr('action','/admin/plane');
                                                $('#myModal').modal();
                                            }
                                  
                                        </script>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      
                      
                                          </tbody>
                      
                                        </table>
                                      </div><!-- /.box-body -->
                                    </div><!-- /.box -->
                                  </div><!-- /.col -->
                                </div><!-- /.row -->
                              </section><!-- /.content -->
                                
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ajyal\resources\views/admin/pages/plane/plane_table.blade.php ENDPATH**/ ?>